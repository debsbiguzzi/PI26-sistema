@echo off
:: ════════════════════════════════════════════════════════════════
::  Dashboard Econômico Brasileiro — Start Script (Windows)
::  Double-click this file to start the server.
:: ════════════════════════════════════════════════════════════════
title Dashboard Economico

echo.
echo  ╔══════════════════════════════════════════╗
echo  ║   Dashboard Econômico Brasileiro         ║
echo  ╚══════════════════════════════════════════╝
echo.

:: ── Check Python ─────────────────────────────────────────────────
python --version >nul 2>&1
if errorlevel 1 (
    echo  [ERRO] Python nao encontrado.
    echo  Instale em: https://python.org/downloads
    pause
    exit /b 1
)

:: ── Install dependencies if needed ───────────────────────────────
echo  Verificando dependencias...
pip install -r requirements.txt -q
if errorlevel 1 (
    echo  [ERRO] Falha ao instalar dependencias.
    pause
    exit /b 1
)

:: ── Create .env if it doesn't exist ──────────────────────────────
if not exist .env (
    echo  Criando arquivo .env...
    echo # Dashboard Econômico — Configuração> .env
    echo #>> .env
    echo # Chave da API Anthropic (obtenha em console.anthropic.com)>> .env
    echo # ANTHROPIC_API_KEY=sk-ant-...>> .env
    echo #>> .env
    echo # Banco de dados (padrão: SQLite — não precisa configurar)>> .env
    echo # DATABASE_URL=postgresql://postgres:senha@localhost:5432/econ_dashboard>> .env
    echo.
    echo  [INFO] Arquivo .env criado. Edite-o para adicionar sua chave Anthropic.
    echo         As projecoes IA ficam desativadas sem a chave.
    echo.
)

:: ── Start server ─────────────────────────────────────────────────
echo  Iniciando servidor...
echo  Acesse: http://localhost:8000
echo  Pressione Ctrl+C para parar.
echo.
uvicorn main:app --host 0.0.0.0 --port 8000 --reload
pause
